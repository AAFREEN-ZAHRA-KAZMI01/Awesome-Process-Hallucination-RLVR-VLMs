How to open in Overleaf
1. Overleaf > New Project > Upload Project > select this zip.
2. Menu > Compiler: pdfLaTeX; Main document: main.tex.
3. Recompile. Bibliography (references.bib, IEEEtran.bst) is built automatically.
Files: main.tex (paper, IEEE journal format, IEEEtran.cls), references.bib, tab_extract.tex (Appendix table), figs/ (400-DPI figures).
